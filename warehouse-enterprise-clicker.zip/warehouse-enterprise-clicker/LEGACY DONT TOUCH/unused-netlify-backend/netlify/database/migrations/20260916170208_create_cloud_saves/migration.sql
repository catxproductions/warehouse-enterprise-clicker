CREATE TABLE "cloud_saves" (
	"id" serial PRIMARY KEY,
	"code" text NOT NULL UNIQUE,
	"save_version" integer DEFAULT 1 NOT NULL,
	"payload" jsonb NOT NULL,
	"company_name" text DEFAULT '' NOT NULL,
	"total_shipped" double precision DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
