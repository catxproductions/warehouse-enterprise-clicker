import type { Config, Context } from "@netlify/functions";
import { eq, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { cloudSaves } from "../../db/schema.js";

// Codes are typed in by hand, so the alphabet leaves out characters that are
// easy to confuse (0/O, 1/I/L, 5/S, 2/Z).
const CODE_ALPHABET = "ABCDEFGHJKMNPQRTUVWXY3467689";
const CODE_GROUPS = 3;
const CODE_GROUP_LENGTH = 4;
const MAX_PAYLOAD_BYTES = 64 * 1024;
const MAX_CODE_ATTEMPTS = 6;

const jsonResponse = (body: unknown, status = 200) =>
  Response.json(body, {
    status,
    headers: { "cache-control": "no-store" },
  });

function generateCode() {
  const bytes = new Uint8Array(CODE_GROUPS * CODE_GROUP_LENGTH);
  crypto.getRandomValues(bytes);
  const characters = Array.from(bytes, (byte) => CODE_ALPHABET[byte % CODE_ALPHABET.length]);
  const groups: string[] = [];
  for (let index = 0; index < CODE_GROUPS; index += 1) {
    groups.push(characters.slice(index * CODE_GROUP_LENGTH, (index + 1) * CODE_GROUP_LENGTH).join(""));
  }
  return groups.join("-");
}

/** Accepts codes with or without dashes and in any case, e.g. "abcd efgh ijkl". */
function normaliseCode(raw: string | undefined | null) {
  const cleaned = (raw || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (cleaned.length !== CODE_GROUPS * CODE_GROUP_LENGTH) return null;
  const groups = cleaned.match(new RegExp(`.{1,${CODE_GROUP_LENGTH}}`, "g")) || [];
  return groups.join("-");
}

function summarise(state: Record<string, unknown>) {
  const settings = (state.settings || {}) as Record<string, unknown>;
  const companyName = typeof settings.company === "string" ? settings.company.slice(0, 40) : "";
  const totalShipped = Number(state.totalShipped);
  return {
    companyName,
    totalShipped: Number.isFinite(totalShipped) && totalShipped >= 0 ? totalShipped : 0,
  };
}

async function readSave(code: string) {
  const [row] = await db
    .select({
      code: cloudSaves.code,
      saveVersion: cloudSaves.saveVersion,
      payload: cloudSaves.payload,
      companyName: cloudSaves.companyName,
      updatedAt: cloudSaves.updatedAt,
    })
    .from(cloudSaves)
    .where(eq(cloudSaves.code, code))
    .limit(1);
  return row;
}

async function handleUpload(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "Request body must be JSON." }, 400);
  }

  const state = body.state;
  if (!state || typeof state !== "object" || Array.isArray(state)) {
    return jsonResponse({ error: "A save `state` object is required." }, 400);
  }

  const serialised = JSON.stringify(state);
  if (new TextEncoder().encode(serialised).length > MAX_PAYLOAD_BYTES) {
    return jsonResponse({ error: "Save data is too large to store." }, 413);
  }

  const saveVersionInput = Number(body.saveVersion);
  const saveVersion = Number.isInteger(saveVersionInput) && saveVersionInput > 0 ? saveVersionInput : 1;
  const summary = summarise(state as Record<string, unknown>);

  // An existing code overwrites that slot; otherwise a fresh slot is created.
  if (body.code !== undefined && body.code !== null && body.code !== "") {
    const code = normaliseCode(String(body.code));
    if (!code) return jsonResponse({ error: "That save code is not valid." }, 400);

    const [updated] = await db
      .update(cloudSaves)
      .set({
        payload: state,
        saveVersion,
        companyName: summary.companyName,
        totalShipped: summary.totalShipped,
        updatedAt: sql`now()`,
      })
      .where(eq(cloudSaves.code, code))
      .returning({ code: cloudSaves.code, updatedAt: cloudSaves.updatedAt });

    if (updated) return jsonResponse({ code: updated.code, updatedAt: updated.updatedAt, created: false });
    // The code is well formed but unknown (for example the slot was created on a
    // different deploy context), so fall through and mint a new one.
  }

  for (let attempt = 0; attempt < MAX_CODE_ATTEMPTS; attempt += 1) {
    const code = generateCode();
    const [inserted] = await db
      .insert(cloudSaves)
      .values({
        code,
        payload: state,
        saveVersion,
        companyName: summary.companyName,
        totalShipped: summary.totalShipped,
      })
      .onConflictDoNothing({ target: cloudSaves.code })
      .returning({ code: cloudSaves.code, updatedAt: cloudSaves.updatedAt });

    if (inserted) return jsonResponse({ code: inserted.code, updatedAt: inserted.updatedAt, created: true }, 201);
  }

  return jsonResponse({ error: "Could not allocate a save code. Please try again." }, 503);
}

async function handleDownload(rawCode: string | undefined) {
  const code = normaliseCode(rawCode);
  if (!code) return jsonResponse({ error: "That save code is not valid." }, 400);

  const row = await readSave(code);
  if (!row) return jsonResponse({ error: "No cloud save found for that code." }, 404);

  return jsonResponse({
    code: row.code,
    saveVersion: row.saveVersion,
    companyName: row.companyName,
    updatedAt: row.updatedAt,
    state: row.payload,
  });
}

export default async (req: Request, context: Context) => {
  try {
    if (req.method === "POST") return await handleUpload(req);
    if (req.method === "GET") return await handleDownload(context.params?.code);
    return jsonResponse({ error: "Method not allowed." }, 405);
  } catch (error) {
    console.error("cloud-save failed", error);
    return jsonResponse({ error: "Cloud save is unavailable right now." }, 500);
  }
};

export const config: Config = {
  path: ["/api/cloud-save", "/api/cloud-save/:code"],
  method: ["GET", "POST"],
};
