# Unused Netlify backend

This folder holds a partially-built "cloud save" feature: a Netlify Function
(`netlify/functions/cloud-save.mts`) backed by Postgres via Netlify DB and
Drizzle ORM (`db/`, `drizzle.config.ts`), with its dependencies in
`package.json`.

It was never wired up — neither `index.html` nor `download.html` calls it —
and it can't run on GitHub Pages, which only serves static files (no
server-side functions, no database). It's kept here in case you want to
revive the idea on a host that supports serverless functions (Netlify,
Vercel, Cloudflare Workers, etc.). It has no effect on the game as it stands;
the game only uses browser `localStorage`.
