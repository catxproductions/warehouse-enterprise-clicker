import { pgTable, serial, text, integer, jsonb, doublePrecision, timestamp } from "drizzle-orm/pg-core";

/**
 * One row per cloud save slot. The player keeps the short `code` and can use it
 * to pull their progress back down on any other device or browser.
 */
export const cloudSaves = pgTable("cloud_saves", {
  id: serial().primaryKey(),
  code: text().notNull().unique(),
  saveVersion: integer("save_version").notNull().default(1),
  payload: jsonb().notNull(),
  companyName: text("company_name").notNull().default(""),
  totalShipped: doublePrecision("total_shipped").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
